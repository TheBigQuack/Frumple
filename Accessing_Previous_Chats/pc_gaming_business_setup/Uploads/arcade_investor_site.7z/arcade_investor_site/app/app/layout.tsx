
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "PixelPalace - Premium Gaming Lounge Investment Opportunity",
  description: "Discover the future of social entertainment. A revolutionary arcade lounge combining premium gaming, craft beverages, and authentic experiences.",
  keywords: "arcade lounge, gaming investment, entertainment venue, business opportunity, investor presentation",
  authors: [{ name: "PixelPalace Holdings LLC" }],
  viewport: "width=device-width, initial-scale=1",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={inter.className}>
        <ThemeProvider
          attribute="class"
          defaultTheme="dark"
          enableSystem={false}
          disableTransitionOnChange
        >
          {children}
          <Toaster />
        </ThemeProvider>
      </body>
    </html>
  )
}
